# flamo-coal-system

Framework-independent Web Component exported by Flamo.

Set the element's width and height with CSS (default 300px by 150px). Content follows
the exported fit mode in manifest.viewport and adapts when the container resizes.
Width fit scrolls vertically; height fit scrolls horizontally when needed.
The canvas background is transparent; authored node fills are preserved. Host CSS
can supply a background. Canvas movement and zoom are disabled unless enabled at export.
Source maps are included only when Source Map is checked at export (default off).
The selection is recorded in manifest.packaging.sourceMap.

Keep dist/resources/ and dist/component-resources.js alongside the entry modules.
All four entry modes share these files. Serve them over HTTP(S); cross-origin
hosting must allow CORS for the JSON and binary resources as well as JavaScript.
Full diagnostic IR is available only when packaging with diagnosticIR=1.

## Use In HTML

```html
<!-- Put these in head so unupgraded light DOM never flashes. -->
<style>[data-flamo-component]:not([data-flamo-state="ready"]){opacity:0;pointer-events:none}</style>
<link rel="stylesheet" href="./dist/component-loading.css">
<script type="module" src="./dist/flamo-coal-system.loader.js"></script>
<div class="flamo-component-shell" style="width: 100%; height: 400px;">
  <flamo-coal-system data-flamo-component inert aria-busy="true" loading-label="正在加载组件…">
    <div slot="robot" data-mark="&lt;p&gt;机器人占位&lt;/p&gt;"></div>
    <div slot="Alarm3A__166_1" data-mark=""></div>
    <div slot="Alarm3A__169_0" data-mark=""></div>
    <div slot="Alarm1A__176_0" data-mark=""></div>
    <div slot="Alarm2A" data-mark=""></div>
    <div slot="Alarm2B" data-mark=""></div>
    <div slot="Alarm3B" data-mark=""></div>
    <div slot="Alarm4A" data-mark=""></div>
    <div slot="Alarm6A" data-mark=""></div>
    <div slot="Alarm6C" data-mark=""></div>
    <div slot="Alarm6D" data-mark=""></div>
    <div slot="Alarm6B" data-mark=""></div>
    <div slot="Alarm5A" data-mark=""></div>
    <div slot="Alarm5B" data-mark=""></div>
    <div slot="1A皮带电机电流" data-mark=""></div>
    <div slot="1B皮带电机电流" data-mark=""></div>
    <div slot="2A皮带电机电流" data-mark=""></div>
    <div slot="2B皮带电机电流" data-mark=""></div>
    <div slot="3A皮带电机电流" data-mark=""></div>
    <div slot="3B皮带电机电流" data-mark=""></div>
    <div slot="4A皮带电机电流" data-mark=""></div>
    <div slot="4B皮带电机电流" data-mark=""></div>
    <div slot="5B皮带电机电流" data-mark=""></div>
    <div slot="6A皮带电机电流" data-mark=""></div>
    <div slot="6B皮带电机电流" data-mark=""></div>
    <div slot="6C皮带电机电流" data-mark=""></div>
    <div slot="6D皮带电机电流" data-mark=""></div>
    <div slot="1F原煤仓料位" data-mark=""></div>
    <div slot="1E原煤仓料位" data-mark=""></div>
    <div slot="1D原煤仓料位" data-mark=""></div>
    <div slot="1C原煤仓料位" data-mark=""></div>
    <div slot="1B原煤仓料位" data-mark=""></div>
    <div slot="1A原煤仓料位" data-mark=""></div>
    <div slot="2F原煤仓料位" data-mark=""></div>
    <div slot="2E原煤仓料位" data-mark=""></div>
    <div slot="2D原煤仓料位" data-mark=""></div>
    <div slot="2C原煤仓料位" data-mark=""></div>
    <div slot="2B原煤仓料位" data-mark=""></div>
    <div slot="2A原煤仓料位" data-mark=""></div>
    <div slot="Alarm4B" data-mark=""></div>
    <div slot="5A皮带电机电流" data-mark=""></div>
    <div slot="Alarm1A2" data-mark=""></div>
    <div slot="Alarm6C2" data-mark=""></div>
    <div slot="Alarm1A__325_2" data-mark=""></div>
    <div slot="Alarm1B" data-mark=""></div>
    <div slot="Robot" data-mark=""></div>
    <div slot="消防高位水箱水位" data-mark=""></div>
  </flamo-coal-system>
  <div data-flamo-status role="status" aria-live="polite">
    <span data-flamo-message>正在加载组件…</span>
    <button type="button" hidden>刷新重试</button>
  </div>
</div>
```

## Use In JavaScript

```js
import './dist/flamo-coal-system.js';

const el = document.createElement('flamo-coal-system');
el.addEventListener('flamo-ready', (event) => {
  console.log(event.detail.app, event.detail.flamo, event.detail.manifest);
});
document.body.append(el);
```

## Slot 接入合同

| Slot | 说明 | 必填 | 默认内容 | 接受内容 |
|---|---|---|---|---|
| robot | &lt;p&gt;机器人占位&lt;/p&gt; | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm3A__166_1 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm3A__169_0 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm1A__176_0 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm2A | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm2B | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm3B | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm4A | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm6A | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm6C | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm6D | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm6B | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm5A | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm5B | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 1A皮带电机电流 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 1B皮带电机电流 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 2A皮带电机电流 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 2B皮带电机电流 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 3A皮带电机电流 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 3B皮带电机电流 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 4A皮带电机电流 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 4B皮带电机电流 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 5B皮带电机电流 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 6A皮带电机电流 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 6B皮带电机电流 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 6C皮带电机电流 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 6D皮带电机电流 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 1F原煤仓料位 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 1E原煤仓料位 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 1D原煤仓料位 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 1C原煤仓料位 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 1B原煤仓料位 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 1A原煤仓料位 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 2F原煤仓料位 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 2E原煤仓料位 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 2D原煤仓料位 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 2C原煤仓料位 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 2B原煤仓料位 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 2A原煤仓料位 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm4B | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 5A皮带电机电流 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm1A2 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm6C2 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm1A__325_2 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Alarm1B | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| Robot | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |
| 消防高位水箱水位 | 未提供说明 | 否 | 无 | artifact, flamoInstance, dom, html, text |

在 Figma 主组件右侧 Properties 中编辑 Slot property 的 description，重新同步再导出。
data-mark 是 description 的 HTML 副本，完整合同见 manifest.json 的 slots。
Slot 名称区分大小写；不要根据缩写猜测接口字段。没有说明时先结合项目资料补充业务含义。
上面的完整骨架中，有默认内容或不接受 DOM 的 slot 已注释；需要替换时再启用 DOM 占位，
非 DOM slot 使用 manifest 声明的内容类型。空 div 也是显式内容，会覆盖默认内容。

源 light DOM 的属性、文字和子节点变化会同步到各个投影；不要访问 shadowRoot 修改副本。
自定义 DOM 属性和 addEventListener 不会由克隆复制；有独立状态或交互的内容使用自行初始化的
Custom Element，或组件声明的 slot props/events 合同。template 内容可重复挂载。
宿主页面 CSS 不会自动进入投影；通过组件的 slotStyles 属性提供限定到 slot 内容的 CSS，
例如 el.slotStyles = '[slot] { color: white; }'。空字符串清除样式。
样式中的相对 URL 相对于宿主文档解析。运行、停止、未知状态、素材和 API 映射属于接入项目。

## Public API

- Properties and imperative methods listed in manifest.surface and the exact .d.ts are available directly on the element. Scalar attribute names come from custom-elements.json; object/array inputs use DOM properties. Property assignments do not reflect back to HTML attributes.
- Set initial properties before insertion if needed. After insertion, await `el.ready` before invoking methods; before custom-element registration first await `customElements.whenDefined('flamo-coal-system')`. Calls while disconnected/loading fail explicitly. Reconnect preserves host property inputs and creates fresh interactions.
- Use `inspectComponentIntegration(el, flamoComponentManifest).publicSurface` to check actual accessors/methods. A method resolving or host label changing is not proof of the component effect; observe state/events or rendered output. Re-export legacy packages whose declared members are absent.
- `ready`: Promise resolved after scene, interactions, initial slot images and a rendered frame are ready (also when paused).
- `data-flamo-state`: loading / ready / error, with `aria-busy` and `flamo-loading`, `flamo-ready`, `flamo-error` events.
- The optional loading shell catches module/runtime failures and shows a manual refresh action after 45 seconds. Late success recovers automatically. Customize colors with `--flamo-loading-accent` and `--flamo-loading-color`.
- `instance`: mounted FlamoInstance owned by this custom element.
- `app`: underlying FlamoApp instance.
- `flamo`: interaction runtime API passed to generated scripts.
- `reloadInteractions()`: re-runs the packaged interaction entry.
- Standard light DOM slots: use native `slot="name"`; slot props are delivered through `element.flamoSlotProps` and `flamo-slot-props-change`.
- `slotStyles: string`: CSS for projected slot content, assign before or after ready; does not require Shadow DOM access.
- `destroy()`: stops and releases the runtime.
- `paused` attribute: pauses rendering while present.

## AI Notes

Start with manifest.integration and the owning Flamo server's flamo-design MCP. Call flamo_component_resolve with its projectId/contractId, then context/api/plan. Submit local browser observations through flamo_component_verify; use flamo_component_source for source revision and re-export guidance. See AGENTS.md for the full workflow. Keep the installed contractId pinned rather than requesting latest APIs.

Read INTERACTIONS.md and interactions.json for per-node design requirements, exact targets and diagnostics.
Use INTERACTION_API.md for Canvas target access and lifecycle. Documentation does not imply implemented behavior.

Start with `AGENTS.md`, `manifest.json`, and `dist/flamo-coal-system.d.ts`. Use native Custom Elements, light DOM, DOM properties and CustomEvent.
The public tag is stable across compatible releases. Replace package resources together and keep host integration outside the exported directory.
Renaming slots or changing props/events is a contract change; review the manifest before upgrading. Different definitions cannot register the same tag in one registry.

Public Runtime and viewport resources are included. Project interactions stay local.

## 运行态加载

此包保留原生模块加载，以兼容脚本的 URL 或依赖语义；具体模式见 `dist/interactions/loading.json`。 资源分块共享进行中的请求及最多 32 MiB 已校验字节，各实例仍独立解码，不共享可变状态。无 CDN 配置的 thin 入口使用 interactions-thin/，与宿主共享 /vendor/flamo-runtime/index.es.js，不另加载包内 Runtime。建议宿主开启 gzip/Brotli，并将每次更新部署到新的版本目录；此优化不自动改变宿主的缓存响应头。
