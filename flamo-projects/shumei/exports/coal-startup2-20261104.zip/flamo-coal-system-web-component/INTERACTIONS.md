# Component interaction requirements

Design annotations are requirements, not proof of implemented behavior. Read manifest.json for real public APIs.

## annotation-03af98040ab3e1c0

斜皮带犁煤器组件 描述：

1，组件属性

taiqiRun （犁煤器抬起状态）

luoxiaRun （犁煤器落下状态）

zhongjianRun （犁煤器中间态）

2，交互说明

taiqiRun 取值为 true 时，“抬起” 节点显示，反之隐藏。

luoxiaRun 取值为 true 时，“落下” 节点显示，反之隐藏。

zhongjianRun 取值为 true 时，“中间位” 节点显示，反之隐藏。

- Category: 12:1
- Source: figma-annotation / 94:101272
- Implementation: unspecified
- Target: target-d9c1b95473528e73 — 6A皮带D犁煤器; resolved; runtime-node
- Target: target-5cf51a1976b6a55d — 6A皮带E犁煤器; resolved; runtime-node
- Target: target-544bed1971cf2b3c — 6A皮带F犁煤器; resolved; runtime-node
- Target: target-e6c2bf225159b39b — 6A皮带B犁煤器; resolved; runtime-node
- Target: target-de189a224c709412 — 6A皮带C犁煤器; resolved; runtime-node
- Target: target-d7f6e95e93648652 — 6B皮带D犁煤器; resolved; runtime-node
- Target: target-0345b25eabeb732f — 6B皮带E犁煤器; resolved; runtime-node
- Target: target-0bfcdb5eb0df23e0 — 6B皮带F犁煤器; resolved; runtime-node
- Target: target-f9c28d5ea64a62e6 — 6B皮带B犁煤器; resolved; runtime-node
- Target: target-9a7ac65e70534e73 — 6B皮带C犁煤器; resolved; runtime-node
- Target: target-2127563b6875a93f — 6C皮带D犁煤器; resolved; runtime-node
- Target: target-29047f3b6cafb630 — 6C皮带E犁煤器; resolved; runtime-node
- Target: target-0f08083b5df7affd — 6C皮带F犁煤器; resolved; runtime-node
- Target: target-fda7b23b541c852b — 6C皮带B犁煤器; resolved; runtime-node
- Target: target-065edb3b591035dc — 6C皮带C犁煤器; resolved; runtime-node
- Target: target-3c69f922f41bd293 — 6D皮带D犁煤器; resolved; runtime-node
- Target: target-9bb2c0232a149a06 — 6D皮带E犁煤器; resolved; runtime-node
- Target: target-931697232537b10d — 6D皮带F犁煤器; resolved; runtime-node
- Target: target-a9f4271a1492fd34 — 6D皮带B犁煤器; resolved; runtime-node
- Target: target-8ff7b01a05daf701 — 6D皮带C犁煤器; resolved; runtime-node

## annotation-0974ac2ee90f097c

滚轴筛组件 描述：

1，组件属性

gzRun （滚轴筛运行状态）

2，交互说明

取值为 0 时，代表停止，“电机运行” 节点隐藏，“电机停止” 节点展示。

取值为 1 时，代表运行，“电机运行” 节点展示，“电机停止” 节点隐藏。

- Category: 12:1
- Source: figma-annotation / 221:951
- Implementation: unspecified
- Target: target-b2befc59b63dba72 — A滚轴筛; resolved; runtime-node
- Target: target-2cb98d449e748dc0 — B滚轴筛; resolved; runtime-node

## annotation-21563912a055dce5

皮带电机组件 描述：

1，组件属性

djRun （皮带电机运行状态）

2，交互说明

djRun 取值【0，1】

取值为 0 时，代表停止，电机运行 图片隐藏，点击停运 图片展示。

取值为 1 时，代表运行，交互和取值为 0 相反。

- Category: 12:1
- Source: figma-annotation / 94:101607
- Implementation: unspecified
- Target: target-566c66dc7a3f87af — 皮带电机; resolved; runtime-node
- Target: target-4d1356e5019089cc — 皮带电机; resolved; runtime-node
- Target: target-6066695a3c412f1e — 皮带电机; resolved; runtime-node
- Target: target-674d04eb58c29897 — 皮带电机; resolved; runtime-node
- Target: target-0ecc22caa780730d — 皮带电机; resolved; runtime-node
- Target: target-a14ff0d387157efc — 皮带电机; resolved; runtime-node
- Target: target-a60136ca6be84e51 — 皮带电机; resolved; runtime-node
- Target: target-136f64c18c46fe3a — 皮带电机; resolved; runtime-node
- Target: target-ec267eca93e0f2b9 — 皮带电机; resolved; runtime-node
- Target: target-361508c19fe67e8e — 皮带电机; resolved; runtime-node
- Target: target-1bce56bb48a9de9b — 皮带电机; resolved; runtime-node
- Target: target-f927b2bb3508ab47 — 1B皮带电机; resolved; runtime-node
- Target: target-d5a80ebb20af8733 — 1A皮带电机; resolved; runtime-node
- Target: target-44a760eb45231843 — 皮带电机; resolved; runtime-node

## annotation-284d3ccd528940fb

叶轮给煤机组件 描述：

1，组件属性

gmjPosition1 （#1给煤机位置的进度条宽度）

gmjPosition2 （#2给煤机位置的进度条宽度）

gmjRun1 （#1给煤机是否运行， true 运行， false 停止）

gmjRun2 （#2给煤机是否运行， true 运行， false 停止）

2，交互说明

gmjPosition1 控制 "#1给煤机位置" 节点下的 “进度条” 节点宽度，取值范围是 &#91;0,53&#93; ，含义是将 "#1给煤机位置" 节点的宽度分为 53 份，“进度条” 节点宽度占其中的几份。

gmjPosition2 与 gmjPosition1 交互类似，控制的是 "#2给煤机位置" 节点下的 “进度条” 节点宽度。

gmjRun1 控制的是 “1#叶轮给煤机” 节点下的 运行和停止 两个图片的展示隐藏状态，当为 true 时 “叶轮给煤机运行” 图片展示，停止图片隐藏，反之运行图片隐藏，停止图片展示。

gmjRun2 与 gmjRun1 交互类似，控制的是 "2#叶轮给煤机" 节点下的 运行和停止 图片。

- Category: 12:1
- Source: figma-annotation / 209:639
- Implementation: unspecified
- Target: target-ab73134c60481177 — 叶轮给煤机-1A皮带; resolved; runtime-node
- Target: target-6de274b3a3fcd2a1 — 叶轮给煤机-1B皮带; resolved; runtime-node

## annotation-338e3e412a486b75

碎煤机组件 描述：

1，组件属性

smjRun （碎煤机运行状态）

2，交互说明

取值为 0 时，代表停止，“碎煤机运行组” 节点隐藏，“碎煤机停止组” 节点展示。

取值为 1 时，代表运行，“碎煤机运行组” 节点展示，“碎煤机停止组” 节点隐藏。

- Category: 12:1
- Source: figma-annotation / 209:818
- Implementation: unspecified
- Target: target-686721404a202e10 — A碎煤机; resolved; runtime-node
- Target: target-b33daf3756eba1cd — B碎煤机; resolved; runtime-node

## annotation-e3663608dd8645cc

三通组件 描述：

1， 组件属性

leftRun （左运行态）

rightRun （右运行态）

2，交互说明

leftRun 为 true 时，代表左管运行，展示：“左管运行”、“上管运行” 节点，隐藏 “左管停止” 节点。为 false 时，代表左管停止，展示 “左管停止” 节点，隐藏 “左管运行” 节点。

rightRun 为 true 时，代表右管运行，展示：“右管运行”、“上管运行” 节点，隐藏 “右管停止” 节点。为 false 时，代表右管停止，展示 “右管停止” 节点，隐藏 “右管运行” 节点。

leftRun 和 rightRun 同时为 false 时，代表左右管都停止，展示 “上管停止” 节点，隐藏 “上管运行” 节点。

- Category: 12:1
- Source: figma-annotation / 94:101763
- Implementation: unspecified
- Target: target-28302efde2b57895 — 3B三通; resolved; runtime-node
- Target: target-0d4cb3fdd3393d7a — 3A三通; resolved; runtime-node
- Target: target-577bf227acfc1da7 — 2B三通; resolved; runtime-node
- Target: target-5076b01f1caaed58 — 2A三通; resolved; runtime-node

## annotation-eb06b0ff629d17b4

斜皮带犁煤器组件 描述：

1，组件属性

taiqiRun （犁煤器抬起状态）

luoxiaRun （犁煤器落下状态）

zhongjianRun （犁煤器中间态）

2，交互说明

taiqiRun 取值为 true 时，“抬起” 节点显示，反之隐藏。

luoxiaRun 取值为 true 时，“落下” 节点显示，反之隐藏。

zhongjianRun 取值为 true 时，“中间位” 节点显示，反之隐藏。

- Category: 12:1
- Source: figma-annotation / 94:101209
- Implementation: unspecified
- Target: target-e795fc63e19accd8 — 5A皮带6B犁煤器; resolved; runtime-node
- Target: target-aa19e163be89a291 — 5A皮带6C犁煤器; resolved; runtime-node
- Target: target-ed3ff5bbff03735e — 5A皮带6D犁煤器; resolved; runtime-node
- Target: target-0c90a475a0ba6ebe — 5B皮带6C犁煤器; resolved; runtime-node
- Target: target-f2f21f3a4b0a02c6 — 5B皮带6D犁煤器; resolved; runtime-node
- Target: target-4866c375c26495ad — 5B皮带6B犁煤器; resolved; runtime-node

## annotation-f25d32ef8af5107b

输煤组件 描述：

1，组件属性

uiBindIds （该组件内所有绑点的位置及值）

2，交互说明

2.1，uiBindIds 结构如下： &#91;{id:"GMJ_1APD#1GMJWZ",notes:"给煤机_1A皮带#1给煤机位置",value: 23}&#93; ，id 代表该组件内某个位置，示例中表示 “叶轮给煤机-1A皮带” 实例的 gmjPosition1 属性的值是 23 ， 组件内所有可能绑定的位置参考 config.js 中的 window.loadConfig.points 。2.2，所有皮带运行时，对应的电机处于运行态，反之电机处于停止态。当“2A皮带”运行时展示“2A皮带落煤_GIF”，“2B皮带”运行时展示“2B皮带落煤_GIF”，“3A皮带”运行时展示“3A皮带落煤_GIF”，“3B皮带”运行时展示“3B皮带落煤_GIF”

2.3，所有电机电流插槽需要宿主用html来展示文本数值和单位 "A"，例如：32.22 A ，文字大小 15px ，颜色 #09BAEB ，加粗。

2.4，Robot 插槽需要宿主嵌入 svg 实现，先预留位置不做任何处理。

2.5，所有报警插槽都是一个带尾巴的消息气泡，气泡尾巴指向 “定位点” 节点的位置，气泡框处于和“定位点”对立的位置，尽量和“定位点”拉开距离，所以各个插槽的尾巴形状会不一样，但是整体要美观。报警包含固定的五类：皮带撕裂报警、皮带堵煤报警、皮带跑偏报警、皮带烟火报警、人员入侵报警，以列表形式呈现。

2.6，原料仓料位插槽形式如下：左侧是 9.37 m ，右侧是简单柱图，上下限在 config.js 中的 window.loadConfig.minMaxLimit 中。

2.7，消防高位水箱水位插槽是一个柱图，中间显示水位高度，如：1.67 m ，上下限在 config.js 中的 window.loadConfig.minMaxLimit 中。

- Category: 12:1
- Source: figma-annotation / 166:730
- Implementation: unspecified
- Target: target-513e49dfcc2d7155 — 输煤组件; resolved; runtime-node

## Diagnostics

- annotation_category_unresolved: Category 12:1 has no label in the supplied source.
- annotation_category_unresolved: Category 12:1 has no label in the supplied source.
- annotation_category_unresolved: Category 12:1 has no label in the supplied source.
- annotation_category_unresolved: Category 12:1 has no label in the supplied source.
- annotation_category_unresolved: Category 12:1 has no label in the supplied source.
- annotation_category_unresolved: Category 12:1 has no label in the supplied source.
- annotation_category_unresolved: Category 12:1 has no label in the supplied source.
- annotation_category_unresolved: Category 12:1 has no label in the supplied source.

See INTERACTION_API.md for target access, events and lifecycle. Host integration reports belong outside the generated package.
